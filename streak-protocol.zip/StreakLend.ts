import { u256 } from '@btc-vision/as-bignum/assembly';
import {
    Address,
    Blockchain,
    BytesWriter,
    Calldata,
    encodeSelector,
    OP_NET,
    Revert,
    Selector,
    StoredU256,
    StoredBoolean,
    SafeMath,
    TransferHelper,
} from '@btc-vision/btc-runtime/runtime';

// ============================================================
// Streak_Lend — Lending Pool with APY Math on Bitcoin L1
// ============================================================
// APY Formula: Utilization-based interest rate model
//   baseRate = 2%
//   slope1   = 10% (below kink = 80% utilization)
//   slope2   = 50% (above kink)
//   BorrowAPY = baseRate + slope * utilization
//   SupplyAPY = BorrowAPY * utilization * (1 - fee)
// All rates stored in basis points (10000 = 100%)
// ============================================================

@final
export class StreakLend extends OP_NET {
    // ── Constants (basis points) ───────────────────────────────
    private readonly BASE_RATE_BPS: u256 = u256.fromU32(200);       // 2%
    private readonly SLOPE1_BPS: u256 = u256.fromU32(1000);         // 10%
    private readonly SLOPE2_BPS: u256 = u256.fromU32(5000);         // 50%
    private readonly KINK_BPS: u256 = u256.fromU32(8000);           // 80%
    private readonly PROTOCOL_FEE_BPS: u256 = u256.fromU32(1000);  // 10%
    private readonly BPS_DENOM: u256 = u256.fromU32(10000);

    // ── Storage pointers ───────────────────────────────────────
    private readonly pausedPointer: u16 = Blockchain.nextPointer;
    private readonly totalSupplyPointer: u16 = Blockchain.nextPointer;
    private readonly totalBorrowsPointer: u16 = Blockchain.nextPointer;
    private readonly totalReservesPointer: u16 = Blockchain.nextPointer;
    private readonly lastAccrualBlockPointer: u16 = Blockchain.nextPointer;
    private readonly accInterestPerSharePointer: u16 = Blockchain.nextPointer;
    // user deposits
    private readonly userDepositPointer: u16 = Blockchain.nextPointer;
    // user borrows
    private readonly userBorrowPointer: u16 = Blockchain.nextPointer;
    // user collateral (NFT count — extensible)
    private readonly userCollateralPointer: u16 = Blockchain.nextPointer;
    // user interest debt snapshot
    private readonly userDebtSnapshotPointer: u16 = Blockchain.nextPointer;

    // ── Stored values ──────────────────────────────────────────
    private readonly _paused: StoredBoolean = new StoredBoolean(this.pausedPointer, false);
    private readonly _totalSupply: StoredU256 = new StoredU256(this.totalSupplyPointer, u256.Zero);
    private readonly _totalBorrows: StoredU256 = new StoredU256(this.totalBorrowsPointer, u256.Zero);
    private readonly _totalReserves: StoredU256 = new StoredU256(this.totalReservesPointer, u256.Zero);
    private readonly _lastAccrualBlock: StoredU256 = new StoredU256(this.lastAccrualBlockPointer, u256.Zero);
    private readonly _accInterestPerShare: StoredU256 = new StoredU256(this.accInterestPerSharePointer, u256.Zero);

    // ── Selectors ──────────────────────────────────────────────
    private readonly depositSelector: Selector = encodeSelector('deposit(uint256)');
    private readonly withdrawSelector: Selector = encodeSelector('withdraw(uint256)');
    private readonly borrowSelector: Selector = encodeSelector('borrow(uint256)');
    private readonly repaySelector: Selector = encodeSelector('repay(uint256)');
    private readonly getApySelector: Selector = encodeSelector('getAPY()');
    private readonly getTvlSelector: Selector = encodeSelector('getTVL()');
    private readonly getUserPositionSelector: Selector = encodeSelector('getUserPosition(address)');
    private readonly getLtvSelector: Selector = encodeSelector('getLTV(address)');
    private readonly accrueInterestSelector: Selector = encodeSelector('accrueInterest()');

    // ── Reentrancy guard ───────────────────────────────────────
    private _reentrancyGuard: bool = false;

    public constructor() {
        super();
    }

    public override onDeployment(_calldata: Calldata): void {
        this._lastAccrualBlock.value = Blockchain.block.number;
    }

    public override callMethod(calldata: Calldata): BytesWriter {
        const selector = calldata.readSelector();

        switch (selector) {
            case this.depositSelector:
                return this.deposit(calldata);
            case this.withdrawSelector:
                return this.withdraw(calldata);
            case this.borrowSelector:
                return this.borrow(calldata);
            case this.repaySelector:
                return this.repay(calldata);
            case this.getApySelector:
                return this.getAPY();
            case this.getTvlSelector:
                return this.getTVL();
            case this.getUserPositionSelector:
                return this.getUserPosition(calldata);
            case this.getLtvSelector:
                return this.getLTV(calldata);
            case this.accrueInterestSelector:
                return this.accrueInterest();
            default:
                return super.callMethod(calldata);
        }
    }

    // ── Deposit assets to earn interest ───────────────────────
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @returns({ name: 'shares', type: ABIDataTypes.UINT256 })
    public deposit(calldata: Calldata): BytesWriter {
        this.assertNotPaused();
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const amount: u256 = calldata.readU256();
        if (u256.eq(amount, u256.Zero)) {
            this._reentrancyGuard = false;
            throw new Revert('Deposit amount must be > 0');
        }

        this._accrueInterestInternal();

        const user: Address = Blockchain.tx.sender;
        const currentDeposit: u256 = this._loadUserDeposit(user);
        const newDeposit: u256 = SafeMath.add(currentDeposit, amount);
        this._storeUserDeposit(user, newDeposit);
        this._totalSupply.value = SafeMath.add(this._totalSupply.value, amount);

        // Snapshot accumulated interest per share for user
        this._storeUserDebtSnapshot(user, this._accInterestPerShare.value);

        this._reentrancyGuard = false;

        const response = new BytesWriter(32);
        response.writeU256(amount); // shares = amount (1:1 for scaffold)
        return response;
    }

    // ── Withdraw deposited assets ──────────────────────────────
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public withdraw(calldata: Calldata): BytesWriter {
        this.assertNotPaused();
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const amount: u256 = calldata.readU256();
        const user: Address = Blockchain.tx.sender;
        const currentDeposit: u256 = this._loadUserDeposit(user);

        if (u256.lt(currentDeposit, amount)) {
            this._reentrancyGuard = false;
            throw new Revert('Insufficient deposit balance');
        }

        this._accrueInterestInternal();

        // Check pool liquidity
        const available: u256 = SafeMath.sub(this._totalSupply.value, this._totalBorrows.value);
        if (u256.lt(available, amount)) {
            this._reentrancyGuard = false;
            throw new Revert('Insufficient pool liquidity');
        }

        const newDeposit: u256 = SafeMath.sub(currentDeposit, amount);
        this._storeUserDeposit(user, newDeposit);
        this._totalSupply.value = SafeMath.sub(this._totalSupply.value, amount);

        // Transfer BEFORE updating state (checks-effects-interactions already satisfied above)
        TransferHelper.safeTransfer(Blockchain.tx.origin, user, amount);

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Borrow against collateral ──────────────────────────────
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public borrow(calldata: Calldata): BytesWriter {
        this.assertNotPaused();
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const amount: u256 = calldata.readU256();
        const user: Address = Blockchain.tx.sender;

        this._accrueInterestInternal();

        // LTV check: max 75% of collateral
        const collateral: u256 = this._loadUserCollateral(user);
        const existingBorrow: u256 = this._loadUserBorrow(user);
        const newBorrow: u256 = SafeMath.add(existingBorrow, amount);

        // maxBorrow = collateral * 75 / 100
        const maxBorrow: u256 = SafeMath.div(SafeMath.mul(collateral, u256.fromU32(75)), u256.fromU32(100));
        if (u256.gt(newBorrow, maxBorrow)) {
            this._reentrancyGuard = false;
            throw new Revert('Exceeds maximum LTV (75%)');
        }

        // Check liquidity
        const available: u256 = SafeMath.sub(this._totalSupply.value, this._totalBorrows.value);
        if (u256.lt(available, amount)) {
            this._reentrancyGuard = false;
            throw new Revert('Insufficient pool liquidity');
        }

        this._storeUserBorrow(user, newBorrow);
        this._totalBorrows.value = SafeMath.add(this._totalBorrows.value, amount);

        TransferHelper.safeTransfer(Blockchain.tx.origin, user, amount);

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Repay borrowed amount ──────────────────────────────────
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public repay(calldata: Calldata): BytesWriter {
        this.assertNotPaused();
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const amount: u256 = calldata.readU256();
        const user: Address = Blockchain.tx.sender;
        const existingBorrow: u256 = this._loadUserBorrow(user);

        if (u256.gt(amount, existingBorrow)) {
            this._reentrancyGuard = false;
            throw new Revert('Repay exceeds borrow balance');
        }

        this._accrueInterestInternal();

        const newBorrow: u256 = SafeMath.sub(existingBorrow, amount);
        this._storeUserBorrow(user, newBorrow);
        this._totalBorrows.value = SafeMath.sub(this._totalBorrows.value, amount);

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── View: current APY (supply and borrow) ─────────────────
    @method()
    @returns(
        { name: 'supplyAPY_bps', type: ABIDataTypes.UINT256 },
        { name: 'borrowAPY_bps', type: ABIDataTypes.UINT256 },
        { name: 'utilization_bps', type: ABIDataTypes.UINT256 }
    )
    public getAPY(): BytesWriter {
        const totalSupply: u256 = this._totalSupply.value;
        const totalBorrows: u256 = this._totalBorrows.value;

        const utilization: u256 = this._calcUtilization(totalSupply, totalBorrows);
        const borrowAPY: u256 = this._calcBorrowAPY(utilization);
        const supplyAPY: u256 = this._calcSupplyAPY(borrowAPY, utilization);

        const response = new BytesWriter(96);
        response.writeU256(supplyAPY);
        response.writeU256(borrowAPY);
        response.writeU256(utilization);
        return response;
    }

    // ── View: total value locked ───────────────────────────────
    @method()
    @returns({ name: 'tvl', type: ABIDataTypes.UINT256 })
    public getTVL(): BytesWriter {
        const response = new BytesWriter(32);
        response.writeU256(this._totalSupply.value);
        return response;
    }

    // ── View: user position ────────────────────────────────────
    @method({ name: 'user', type: ABIDataTypes.ADDRESS })
    @returns(
        { name: 'deposited', type: ABIDataTypes.UINT256 },
        { name: 'borrowed', type: ABIDataTypes.UINT256 },
        { name: 'collateral', type: ABIDataTypes.UINT256 }
    )
    public getUserPosition(calldata: Calldata): BytesWriter {
        const user: Address = calldata.readAddress();
        const deposited: u256 = this._loadUserDeposit(user);
        const borrowed: u256 = this._loadUserBorrow(user);
        const collateral: u256 = this._loadUserCollateral(user);

        const response = new BytesWriter(96);
        response.writeU256(deposited);
        response.writeU256(borrowed);
        response.writeU256(collateral);
        return response;
    }

    // ── View: loan-to-value ratio ──────────────────────────────
    @method({ name: 'user', type: ABIDataTypes.ADDRESS })
    @returns({ name: 'ltv_bps', type: ABIDataTypes.UINT256 })
    public getLTV(calldata: Calldata): BytesWriter {
        const user: Address = calldata.readAddress();
        const borrowed: u256 = this._loadUserBorrow(user);
        const collateral: u256 = this._loadUserCollateral(user);

        let ltv: u256 = u256.Zero;
        if (!u256.eq(collateral, u256.Zero)) {
            // LTV in basis points
            ltv = SafeMath.div(
                SafeMath.mul(borrowed, this.BPS_DENOM),
                collateral
            );
        }

        const response = new BytesWriter(32);
        response.writeU256(ltv);
        return response;
    }

    // ── Public interest accrual ────────────────────────────────
    @method()
    @returns({ name: 'accrued', type: ABIDataTypes.BOOL })
    public accrueInterest(): BytesWriter {
        this._accrueInterestInternal();
        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── APY math internals ─────────────────────────────────────

    // Utilization = totalBorrows / totalSupply  (in BPS)
    private _calcUtilization(supply: u256, borrows: u256): u256 {
        if (u256.eq(supply, u256.Zero)) return u256.Zero;
        return SafeMath.div(SafeMath.mul(borrows, this.BPS_DENOM), supply);
    }

    // Borrow APY using kinked interest rate model
    private _calcBorrowAPY(utilization: u256): u256 {
        if (u256.lte(utilization, this.KINK_BPS)) {
            // Below kink: baseRate + slope1 * utilization / KINK
            const extra: u256 = SafeMath.div(SafeMath.mul(this.SLOPE1_BPS, utilization), this.KINK_BPS);
            return SafeMath.add(this.BASE_RATE_BPS, extra);
        } else {
            // Above kink: baseRate + slope1 + slope2 * (util - kink) / (10000 - kink)
            const baseAtKink: u256 = SafeMath.add(this.BASE_RATE_BPS, this.SLOPE1_BPS);
            const excessUtil: u256 = SafeMath.sub(utilization, this.KINK_BPS);
            const remainingRange: u256 = SafeMath.sub(this.BPS_DENOM, this.KINK_BPS);
            const extra2: u256 = SafeMath.div(SafeMath.mul(this.SLOPE2_BPS, excessUtil), remainingRange);
            return SafeMath.add(baseAtKink, extra2);
        }
    }

    // Supply APY = BorrowAPY * utilization * (1 - protocolFee) / BPS^2
    private _calcSupplyAPY(borrowAPY: u256, utilization: u256): u256 {
        if (u256.eq(utilization, u256.Zero)) return u256.Zero;
        const gross: u256 = SafeMath.div(SafeMath.mul(borrowAPY, utilization), this.BPS_DENOM);
        const netFactor: u256 = SafeMath.sub(this.BPS_DENOM, this.PROTOCOL_FEE_BPS);
        return SafeMath.div(SafeMath.mul(gross, netFactor), this.BPS_DENOM);
    }

    // Per-block interest accrual
    private _accrueInterestInternal(): void {
        const currentBlock: u256 = Blockchain.block.number;
        const lastBlock: u256 = this._lastAccrualBlock.value;
        if (u256.eq(currentBlock, lastBlock)) return; // Already accrued this block

        const blockDelta: u256 = SafeMath.sub(currentBlock, lastBlock);
        const totalBorrows: u256 = this._totalBorrows.value;

        if (!u256.eq(totalBorrows, u256.Zero)) {
            const utilization: u256 = this._calcUtilization(this._totalSupply.value, totalBorrows);
            const borrowAPY: u256 = this._calcBorrowAPY(utilization);

            // Per-block rate ≈ APY / 52596 (blocks per year on BTC ~10min)
            const BLOCKS_PER_YEAR: u256 = u256.fromU32(52596);
            const perBlockRate: u256 = SafeMath.div(borrowAPY, BLOCKS_PER_YEAR);

            // Interest = totalBorrows * perBlockRate * blocks / BPS_DENOM
            const interest: u256 = SafeMath.div(
                SafeMath.mul(SafeMath.mul(totalBorrows, perBlockRate), blockDelta),
                this.BPS_DENOM
            );

            // Fee to reserves
            const reserveFee: u256 = SafeMath.div(
                SafeMath.mul(interest, this.PROTOCOL_FEE_BPS),
                this.BPS_DENOM
            );

            this._totalBorrows.value = SafeMath.add(totalBorrows, interest);
            this._totalReserves.value = SafeMath.add(this._totalReserves.value, reserveFee);

            // Update accumulated interest per share for LP reward accounting
            if (!u256.eq(this._totalSupply.value, u256.Zero)) {
                const supplyInterest: u256 = SafeMath.sub(interest, reserveFee);
                const delta: u256 = SafeMath.div(
                    SafeMath.mul(supplyInterest, this.BPS_DENOM),
                    this._totalSupply.value
                );
                this._accInterestPerShare.value = SafeMath.add(
                    this._accInterestPerShare.value,
                    delta
                );
            }
        }

        this._lastAccrualBlock.value = currentBlock;
    }

    // ── Guards ─────────────────────────────────────────────────
    private assertNotPaused(): void {
        if (this._paused.value) throw new Revert('Contract is paused');
    }

    private assertNoReentrancy(): void {
        if (this._reentrancyGuard) throw new Revert('Reentrancy detected');
    }

    // ── Per-user storage helpers ───────────────────────────────
    private _storeUserDeposit(user: Address, amount: u256): void {
        const key = this._userKey(this.userDepositPointer, user);
        Blockchain.setStorageAt(key, amount.toBytes(true));
    }

    private _loadUserDeposit(user: Address): u256 {
        const key = this._userKey(this.userDepositPointer, user);
        const data = Blockchain.getStorageAt(key, new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storeUserBorrow(user: Address, amount: u256): void {
        const key = this._userKey(this.userBorrowPointer, user);
        Blockchain.setStorageAt(key, amount.toBytes(true));
    }

    private _loadUserBorrow(user: Address): u256 {
        const key = this._userKey(this.userBorrowPointer, user);
        const data = Blockchain.getStorageAt(key, new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _loadUserCollateral(user: Address): u256 {
        const key = this._userKey(this.userCollateralPointer, user);
        const data = Blockchain.getStorageAt(key, new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storeUserDebtSnapshot(user: Address, snapshot: u256): void {
        const key = this._userKey(this.userDebtSnapshotPointer, user);
        Blockchain.setStorageAt(key, snapshot.toBytes(true));
    }

    private _userKey(subPointer: u16, user: Address): Uint8Array {
        return encodePointer(subPointer, user.toBytes(), false);
    }
}
