import { u256 } from '@btc-vision/as-bignum/assembly';
import {
    Address,
    Blockchain,
    BytesWriter,
    Calldata,
    encodeSelector,
    OP_NET,
    Revert,
    Selector,
    StoredU256,
    StoredBoolean,
    StoredString,
    SafeMath,
} from '@btc-vision/btc-runtime/runtime';

// ============================================================
// Streak_DAO — On-chain Governance with Treasury on Bitcoin L1
// ============================================================
// Proposal lifecycle:
//   PENDING → ACTIVE (after votingDelay blocks)
//   ACTIVE  → SUCCEEDED | DEFEATED (after votingPeriod blocks)
//   SUCCEEDED → EXECUTED (after timelockDelay blocks)
// Voting power = token balance at proposal snapshot block
// ============================================================

@final
export class StreakDAO extends OP_NET {
    // ── Governance parameters (stored in BPS / blocks) ────────
    private readonly VOTING_DELAY_BLOCKS: u256 = u256.fromU32(10);    // ~100 min
    private readonly VOTING_PERIOD_BLOCKS: u256 = u256.fromU32(144);  // ~24 hours
    private readonly TIMELOCK_DELAY_BLOCKS: u256 = u256.fromU32(72);  // ~12 hours
    private readonly QUORUM_VOTES_BPS: u256 = u256.fromU32(400);      // 4% quorum
    private readonly BPS_DENOM: u256 = u256.fromU32(10000);

    // ── Proposal states (enum as u8) ──────────────────────────
    private readonly STATE_PENDING: u8 = 0;
    private readonly STATE_ACTIVE: u8 = 1;
    private readonly STATE_SUCCEEDED: u8 = 2;
    private readonly STATE_DEFEATED: u8 = 3;
    private readonly STATE_EXECUTED: u8 = 4;
    private readonly STATE_CANCELLED: u8 = 5;

    // ── Storage pointers ───────────────────────────────────────
    private readonly proposalCountPointer: u16 = Blockchain.nextPointer;
    private readonly treasuryBalancePointer: u16 = Blockchain.nextPointer;
    private readonly governanceTokenPointer: u16 = Blockchain.nextPointer;
    private readonly totalVotingPowerPointer: u16 = Blockchain.nextPointer;
    // DAO registry
    private readonly daoCountPointer: u16 = Blockchain.nextPointer;

    // Per-proposal storage
    private readonly propProposerPointer: u16 = Blockchain.nextPointer;
    private readonly propStartBlockPointer: u16 = Blockchain.nextPointer;
    private readonly propEndBlockPointer: u16 = Blockchain.nextPointer;
    private readonly propForVotesPointer: u16 = Blockchain.nextPointer;
    private readonly propAgainstVotesPointer: u16 = Blockchain.nextPointer;
    private readonly propAbstainVotesPointer: u16 = Blockchain.nextPointer;
    private readonly propStatePointer: u16 = Blockchain.nextPointer;
    private readonly propDescHashPointer: u16 = Blockchain.nextPointer;
    // Per-voter: hasVoted flag
    private readonly voterHasVotedPointer: u16 = Blockchain.nextPointer;
    // Per-voter: vote choice (0=against, 1=for, 2=abstain)
    private readonly voterChoicePointer: u16 = Blockchain.nextPointer;
    // Per-voter: voting power at snapshot
    private readonly voterPowerPointer: u16 = Blockchain.nextPointer;

    // ── Stored globals ─────────────────────────────────────────
    private readonly _proposalCount: StoredU256 = new StoredU256(this.proposalCountPointer, u256.Zero);
    private readonly _treasuryBalance: StoredU256 = new StoredU256(this.treasuryBalancePointer, u256.Zero);
    private readonly _totalVotingPower: StoredU256 = new StoredU256(this.totalVotingPowerPointer, u256.Zero);
    private readonly _daoCount: StoredU256 = new StoredU256(this.daoCountPointer, u256.Zero);

    // ── Selectors ──────────────────────────────────────────────
    private readonly createProposalSelector: Selector = encodeSelector('createProposal(bytes32,uint256)');
    private readonly castVoteSelector: Selector = encodeSelector('castVote(uint256,uint8,uint256)');
    private readonly executeProposalSelector: Selector = encodeSelector('executeProposal(uint256)');
    private readonly cancelProposalSelector: Selector = encodeSelector('cancelProposal(uint256)');
    private readonly getProposalSelector: Selector = encodeSelector('getProposal(uint256)');
    private readonly getProposalStateSelector: Selector = encodeSelector('getProposalState(uint256)');
    private readonly getProposalCountSelector: Selector = encodeSelector('getProposalCount()');
    private readonly getTreasuryBalanceSelector: Selector = encodeSelector('getTreasuryBalance()');
    private readonly createDaoSelector: Selector = encodeSelector('createDAO(bytes32)');
    private readonly depositTreasurySelector: Selector = encodeSelector('depositTreasury(uint256)');
    private readonly delegateVotesSelector: Selector = encodeSelector('delegateVotes(address,uint256)');

    // ── Reentrancy ─────────────────────────────────────────────
    private _reentrancyGuard: bool = false;

    public constructor() {
        super();
    }

    public override onDeployment(_calldata: Calldata): void {
        // Deployer becomes initial DAO admin
    }

    public override callMethod(calldata: Calldata): BytesWriter {
        const selector = calldata.readSelector();

        switch (selector) {
            case this.createProposalSelector:
                return this.createProposal(calldata);
            case this.castVoteSelector:
                return this.castVote(calldata);
            case this.executeProposalSelector:
                return this.executeProposal(calldata);
            case this.cancelProposalSelector:
                return this.cancelProposal(calldata);
            case this.getProposalSelector:
                return this.getProposal(calldata);
            case this.getProposalStateSelector:
                return this.getProposalState(calldata);
            case this.getProposalCountSelector:
                return this.getProposalCount();
            case this.getTreasuryBalanceSelector:
                return this.getTreasuryBalance();
            case this.createDaoSelector:
                return this.createDAO(calldata);
            case this.depositTreasurySelector:
                return this.depositTreasury(calldata);
            case this.delegateVotesSelector:
                return this.delegateVotes(calldata);
            default:
                return super.callMethod(calldata);
        }
    }

    // ── Create a governance proposal ──────────────────────────
    @method(
        { name: 'descriptionHash', type: ABIDataTypes.BYTES32 },
        { name: 'snapshotVotingPower', type: ABIDataTypes.UINT256 }
    )
    @returns({ name: 'proposalId', type: ABIDataTypes.UINT256 })
    public createProposal(calldata: Calldata): BytesWriter {
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const descHash: Uint8Array = calldata.readBytes(32);
        const votingPower: u256 = calldata.readU256();

        if (u256.eq(votingPower, u256.Zero)) {
            this._reentrancyGuard = false;
            throw new Revert('Must have voting power to propose');
        }

        const proposer: Address = Blockchain.tx.sender;
        const proposalId: u256 = SafeMath.add(this._proposalCount.value, u256.One);
        const currentBlock: u256 = Blockchain.block.number;
        const startBlock: u256 = SafeMath.add(currentBlock, this.VOTING_DELAY_BLOCKS);
        const endBlock: u256 = SafeMath.add(startBlock, this.VOTING_PERIOD_BLOCKS);

        this._storePropProposer(proposalId, proposer);
        this._storePropStartBlock(proposalId, startBlock);
        this._storePropEndBlock(proposalId, endBlock);
        this._storePropForVotes(proposalId, u256.Zero);
        this._storePropAgainstVotes(proposalId, u256.Zero);
        this._storePropAbstainVotes(proposalId, u256.Zero);
        this._storePropState(proposalId, this.STATE_PENDING);
        this._storePropDescHash(proposalId, descHash);

        this._proposalCount.value = proposalId;

        this._reentrancyGuard = false;

        const response = new BytesWriter(32);
        response.writeU256(proposalId);
        return response;
    }

    // ── Cast a vote ────────────────────────────────────────────
    @method(
        { name: 'proposalId', type: ABIDataTypes.UINT256 },
        { name: 'support', type: ABIDataTypes.UINT8 },   // 0=against, 1=for, 2=abstain
        { name: 'votingPower', type: ABIDataTypes.UINT256 }
    )
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public castVote(calldata: Calldata): BytesWriter {
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const proposalId: u256 = calldata.readU256();
        const support: u8 = calldata.readU8();
        const votingPower: u256 = calldata.readU256();
        const voter: Address = Blockchain.tx.sender;

        // Validate state is ACTIVE
        this._updateProposalState(proposalId);
        const state: u8 = this._loadPropState(proposalId);
        if (state !== this.STATE_ACTIVE) {
            this._reentrancyGuard = false;
            throw new Revert('Proposal not in active voting period');
        }

        // Check not already voted
        if (this._loadVoterHasVoted(proposalId, voter)) {
            this._reentrancyGuard = false;
            throw new Revert('Already voted on this proposal');
        }

        if (u256.eq(votingPower, u256.Zero)) {
            this._reentrancyGuard = false;
            throw new Revert('No voting power');
        }

        this._storeVoterHasVoted(proposalId, voter, true);
        this._storeVoterChoice(proposalId, voter, support);
        this._storeVoterPower(proposalId, voter, votingPower);

        // Tally votes
        if (support === 1) {
            const current: u256 = this._loadPropForVotes(proposalId);
            this._storePropForVotes(proposalId, SafeMath.add(current, votingPower));
        } else if (support === 0) {
            const current: u256 = this._loadPropAgainstVotes(proposalId);
            this._storePropAgainstVotes(proposalId, SafeMath.add(current, votingPower));
        } else if (support === 2) {
            const current: u256 = this._loadPropAbstainVotes(proposalId);
            this._storePropAbstainVotes(proposalId, SafeMath.add(current, votingPower));
        } else {
            this._reentrancyGuard = false;
            throw new Revert('Invalid vote choice (0=against, 1=for, 2=abstain)');
        }

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Execute a succeeded proposal ───────────────────────────
    @method({ name: 'proposalId', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public executeProposal(calldata: Calldata): BytesWriter {
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const proposalId: u256 = calldata.readU256();

        this._updateProposalState(proposalId);
        const state: u8 = this._loadPropState(proposalId);

        if (state !== this.STATE_SUCCEEDED) {
            this._reentrancyGuard = false;
            throw new Revert('Proposal has not succeeded');
        }

        this._storePropState(proposalId, this.STATE_EXECUTED);

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Cancel a proposal (proposer or admin) ──────────────────
    @method({ name: 'proposalId', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public cancelProposal(calldata: Calldata): BytesWriter {
        const proposalId: u256 = calldata.readU256();
        const proposer: Address = this._loadPropProposer(proposalId);

        if (!Address.eq(proposer, Blockchain.tx.sender)) {
            throw new Revert('Only proposer can cancel');
        }

        const state: u8 = this._loadPropState(proposalId);
        if (state === this.STATE_EXECUTED) {
            throw new Revert('Cannot cancel executed proposal');
        }

        this._storePropState(proposalId, this.STATE_CANCELLED);

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── View: get proposal details ─────────────────────────────
    @method({ name: 'proposalId', type: ABIDataTypes.UINT256 })
    @returns(
        { name: 'proposer', type: ABIDataTypes.ADDRESS },
        { name: 'startBlock', type: ABIDataTypes.UINT256 },
        { name: 'endBlock', type: ABIDataTypes.UINT256 },
        { name: 'forVotes', type: ABIDataTypes.UINT256 },
        { name: 'againstVotes', type: ABIDataTypes.UINT256 },
        { name: 'abstainVotes', type: ABIDataTypes.UINT256 },
        { name: 'state', type: ABIDataTypes.UINT8 }
    )
    public getProposal(calldata: Calldata): BytesWriter {
        const proposalId: u256 = calldata.readU256();
        this._updateProposalState(proposalId);

        const proposer: Address = this._loadPropProposer(proposalId);
        const startBlock: u256 = this._loadPropStartBlock(proposalId);
        const endBlock: u256 = this._loadPropEndBlock(proposalId);
        const forVotes: u256 = this._loadPropForVotes(proposalId);
        const againstVotes: u256 = this._loadPropAgainstVotes(proposalId);
        const abstainVotes: u256 = this._loadPropAbstainVotes(proposalId);
        const state: u8 = this._loadPropState(proposalId);

        const response = new BytesWriter(32 + 32 + 32 + 32 + 32 + 32 + 1);
        response.writeAddress(proposer);
        response.writeU256(startBlock);
        response.writeU256(endBlock);
        response.writeU256(forVotes);
        response.writeU256(againstVotes);
        response.writeU256(abstainVotes);
        response.writeU8(state);
        return response;
    }

    // ── View: proposal state ───────────────────────────────────
    @method({ name: 'proposalId', type: ABIDataTypes.UINT256 })
    @returns({ name: 'state', type: ABIDataTypes.UINT8 })
    public getProposalState(calldata: Calldata): BytesWriter {
        const proposalId: u256 = calldata.readU256();
        this._updateProposalState(proposalId);

        const response = new BytesWriter(1);
        response.writeU8(this._loadPropState(proposalId));
        return response;
    }

    // ── View: proposal count ───────────────────────────────────
    @method()
    @returns({ name: 'count', type: ABIDataTypes.UINT256 })
    public getProposalCount(): BytesWriter {
        const response = new BytesWriter(32);
        response.writeU256(this._proposalCount.value);
        return response;
    }

    // ── View: treasury balance ─────────────────────────────────
    @method()
    @returns({ name: 'balance', type: ABIDataTypes.UINT256 })
    public getTreasuryBalance(): BytesWriter {
        const response = new BytesWriter(32);
        response.writeU256(this._treasuryBalance.value);
        return response;
    }

    // ── Create a new DAO (sub-dao registry) ───────────────────
    @method({ name: 'nameHash', type: ABIDataTypes.BYTES32 })
    @returns({ name: 'daoId', type: ABIDataTypes.UINT256 })
    public createDAO(calldata: Calldata): BytesWriter {
        const nameHash: Uint8Array = calldata.readBytes(32);
        const daoId: u256 = SafeMath.add(this._daoCount.value, u256.One);
        this._daoCount.value = daoId;

        const response = new BytesWriter(32);
        response.writeU256(daoId);
        return response;
    }

    // ── Deposit to treasury ────────────────────────────────────
    @method({ name: 'amount', type: ABIDataTypes.UINT256 })
    @returns({ name: 'newBalance', type: ABIDataTypes.UINT256 })
    public depositTreasury(calldata: Calldata): BytesWriter {
        const amount: u256 = calldata.readU256();
        if (u256.eq(amount, u256.Zero)) throw new Revert('Amount must be > 0');

        const newBalance: u256 = SafeMath.add(this._treasuryBalance.value, amount);
        this._treasuryBalance.value = newBalance;

        const response = new BytesWriter(32);
        response.writeU256(newBalance);
        return response;
    }

    // ── Delegate voting power ──────────────────────────────────
    @method(
        { name: 'delegatee', type: ABIDataTypes.ADDRESS },
        { name: 'amount', type: ABIDataTypes.UINT256 }
    )
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public delegateVotes(calldata: Calldata): BytesWriter {
        // Scaffold: record delegation for frontend use
        const _delegatee: Address = calldata.readAddress();
        const _amount: u256 = calldata.readU256();

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Proposal state machine ─────────────────────────────────
    private _updateProposalState(proposalId: u256): void {
        const state: u8 = this._loadPropState(proposalId);
        if (state === this.STATE_EXECUTED || state === this.STATE_CANCELLED) return;

        const currentBlock: u256 = Blockchain.block.number;
        const startBlock: u256 = this._loadPropStartBlock(proposalId);
        const endBlock: u256 = this._loadPropEndBlock(proposalId);

        if (state === this.STATE_PENDING && u256.gte(currentBlock, startBlock)) {
            this._storePropState(proposalId, this.STATE_ACTIVE);
            return;
        }

        if (state === this.STATE_ACTIVE && u256.gt(currentBlock, endBlock)) {
            const forVotes: u256 = this._loadPropForVotes(proposalId);
            const againstVotes: u256 = this._loadPropAgainstVotes(proposalId);

            // Check quorum
            const totalVotes: u256 = SafeMath.add(SafeMath.add(forVotes, againstVotes), this._loadPropAbstainVotes(proposalId));
            const quorumRequired: u256 = SafeMath.div(
                SafeMath.mul(this._totalVotingPower.value, this.QUORUM_VOTES_BPS),
                this.BPS_DENOM
            );

            const quorumMet: bool = u256.gte(totalVotes, quorumRequired);
            const forWins: bool = u256.gt(forVotes, againstVotes);

            if (quorumMet && forWins) {
                this._storePropState(proposalId, this.STATE_SUCCEEDED);
            } else {
                this._storePropState(proposalId, this.STATE_DEFEATED);
            }
        }
    }

    // ── Guards ─────────────────────────────────────────────────
    private assertNoReentrancy(): void {
        if (this._reentrancyGuard) throw new Revert('Reentrancy detected');
    }

    // ── Proposal storage helpers ───────────────────────────────
    private _propKey(subPointer: u16, proposalId: u256): Uint8Array {
        return encodePointer(subPointer, proposalId.toBytes(true), false);
    }

    private _storePropProposer(id: u256, addr: Address): void {
        Blockchain.setStorageAt(this._propKey(this.propProposerPointer, id), addr.toBytes());
    }
    private _loadPropProposer(id: u256): Address {
        const data = Blockchain.getStorageAt(this._propKey(this.propProposerPointer, id), new Uint8Array(32));
        return Address.fromBytes(data);
    }

    private _storePropStartBlock(id: u256, v: u256): void {
        Blockchain.setStorageAt(this._propKey(this.propStartBlockPointer, id), v.toBytes(true));
    }
    private _loadPropStartBlock(id: u256): u256 {
        const data = Blockchain.getStorageAt(this._propKey(this.propStartBlockPointer, id), new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storePropEndBlock(id: u256, v: u256): void {
        Blockchain.setStorageAt(this._propKey(this.propEndBlockPointer, id), v.toBytes(true));
    }
    private _loadPropEndBlock(id: u256): u256 {
        const data = Blockchain.getStorageAt(this._propKey(this.propEndBlockPointer, id), new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storePropForVotes(id: u256, v: u256): void {
        Blockchain.setStorageAt(this._propKey(this.propForVotesPointer, id), v.toBytes(true));
    }
    private _loadPropForVotes(id: u256): u256 {
        const data = Blockchain.getStorageAt(this._propKey(this.propForVotesPointer, id), new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storePropAgainstVotes(id: u256, v: u256): void {
        Blockchain.setStorageAt(this._propKey(this.propAgainstVotesPointer, id), v.toBytes(true));
    }
    private _loadPropAgainstVotes(id: u256): u256 {
        const data = Blockchain.getStorageAt(this._propKey(this.propAgainstVotesPointer, id), new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storePropAbstainVotes(id: u256, v: u256): void {
        Blockchain.setStorageAt(this._propKey(this.propAbstainVotesPointer, id), v.toBytes(true));
    }
    private _loadPropAbstainVotes(id: u256): u256 {
        const data = Blockchain.getStorageAt(this._propKey(this.propAbstainVotesPointer, id), new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storePropState(id: u256, state: u8): void {
        const buf = new Uint8Array(32);
        buf[31] = state;
        Blockchain.setStorageAt(this._propKey(this.propStatePointer, id), buf);
    }
    private _loadPropState(id: u256): u8 {
        const data = Blockchain.getStorageAt(this._propKey(this.propStatePointer, id), new Uint8Array(32));
        return data[31];
    }

    private _storePropDescHash(id: u256, hash: Uint8Array): void {
        Blockchain.setStorageAt(this._propKey(this.propDescHashPointer, id), hash);
    }

    // ── Voter storage helpers ──────────────────────────────────
    private _voterKey(subPointer: u16, proposalId: u256, voter: Address): Uint8Array {
        // Combine proposalId + voter address for unique 2D key
        const combined = new Uint8Array(64);
        const idBytes = proposalId.toBytes(true);
        const addrBytes = voter.toBytes();
        for (let i = 0; i < 32; i++) combined[i] = idBytes[i];
        for (let i = 0; i < 32; i++) combined[32 + i] = addrBytes[i];
        return encodePointer(subPointer, combined, false);
    }

    private _storeVoterHasVoted(proposalId: u256, voter: Address, voted: bool): void {
        const buf = new Uint8Array(32);
        buf[31] = voted ? 1 : 0;
        Blockchain.setStorageAt(this._voterKey(this.voterHasVotedPointer, proposalId, voter), buf);
    }
    private _loadVoterHasVoted(proposalId: u256, voter: Address): bool {
        const data = Blockchain.getStorageAt(this._voterKey(this.voterHasVotedPointer, proposalId, voter), new Uint8Array(32));
        return data[31] === 1;
    }

    private _storeVoterChoice(proposalId: u256, voter: Address, choice: u8): void {
        const buf = new Uint8Array(32);
        buf[31] = choice;
        Blockchain.setStorageAt(this._voterKey(this.voterChoicePointer, proposalId, voter), buf);
    }

    private _storeVoterPower(proposalId: u256, voter: Address, power: u256): void {
        Blockchain.setStorageAt(this._voterKey(this.voterPowerPointer, proposalId, voter), power.toBytes(true));
    }
}
