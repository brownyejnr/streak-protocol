import { u256 } from '@btc-vision/as-bignum/assembly';
import {
    Address,
    Blockchain,
    BytesWriter,
    Calldata,
    encodeSelector,
    OP_NET,
    Revert,
    Selector,
    StoredU256,
    StoredU64,
    AddressMemoryMap,
    SafeMath,
    TransferHelper,
    StoredBoolean,
} from '@btc-vision/btc-runtime/runtime';

// ============================================================
// Streak_Market — Trustless OP-721 NFT Exchange on Bitcoin L1
// ============================================================

@final
export class StreakMarket extends OP_NET {
    // ── Storage pointers (unique, auto-allocated) ──────────────
    private readonly pausedPointer: u16 = Blockchain.nextPointer;
    private readonly feeRecipientPointer: u16 = Blockchain.nextPointer;
    private readonly feeRatePointer: u16 = Blockchain.nextPointer;  // basis points (250 = 2.5%)
    private readonly listingCountPointer: u16 = Blockchain.nextPointer;
    private readonly totalVolumePointer: u16 = Blockchain.nextPointer;
    private readonly floorPricePointer: u16 = Blockchain.nextPointer;

    // listing id → price (u256)
    private readonly listingPricePointer: u16 = Blockchain.nextPointer;
    // listing id → seller address (stored as u256)
    private readonly listingSellerPointer: u16 = Blockchain.nextPointer;
    // listing id → token contract (u256)
    private readonly listingContractPointer: u16 = Blockchain.nextPointer;
    // listing id → token id (u256)
    private readonly listingTokenIdPointer: u16 = Blockchain.nextPointer;
    // listing id → active flag
    private readonly listingActivePointer: u16 = Blockchain.nextPointer;

    // ── Stored values ──────────────────────────────────────────
    private readonly _paused: StoredBoolean = new StoredBoolean(this.pausedPointer, false);
    private readonly _feeRate: StoredU256 = new StoredU256(this.feeRatePointer, u256.fromU32(250));
    private readonly _listingCount: StoredU256 = new StoredU256(this.listingCountPointer, u256.Zero);
    private readonly _totalVolume: StoredU256 = new StoredU256(this.totalVolumePointer, u256.Zero);
    private readonly _floorPrice: StoredU256 = new StoredU256(this.floorPricePointer, u256.Zero);

    // ── Method selectors ───────────────────────────────────────
    private readonly listItemSelector: Selector = encodeSelector('listItem(address,uint256,uint256)');
    private readonly buyItemSelector: Selector = encodeSelector('buyItem(uint256)');
    private readonly cancelListingSelector: Selector = encodeSelector('cancelListing(uint256)');
    private readonly getListingSelector: Selector = encodeSelector('getListing(uint256)');
    private readonly getFloorPriceSelector: Selector = encodeSelector('getFloorPrice()');
    private readonly getTotalVolumeSelector: Selector = encodeSelector('getTotalVolume()');
    private readonly getListingCountSelector: Selector = encodeSelector('getListingCount()');
    private readonly setPausedSelector: Selector = encodeSelector('setPaused(bool)');

    // ── Reentrancy guard ───────────────────────────────────────
    private _reentrancyGuard: bool = false;

    public constructor() {
        super();
    }

    public override onDeployment(_calldata: Calldata): void {
        // Initialize with deployer as fee recipient
        this._paused.value = false;
    }

    public override callMethod(calldata: Calldata): BytesWriter {
        const selector = calldata.readSelector();

        switch (selector) {
            case this.listItemSelector:
                return this.listItem(calldata);
            case this.buyItemSelector:
                return this.buyItem(calldata);
            case this.cancelListingSelector:
                return this.cancelListing(calldata);
            case this.getListingSelector:
                return this.getListing(calldata);
            case this.getFloorPriceSelector:
                return this.getFloorPrice();
            case this.getTotalVolumeSelector:
                return this.getTotalVolume();
            case this.getListingCountSelector:
                return this.getListingCount();
            case this.setPausedSelector:
                return this.setPaused(calldata);
            default:
                return super.callMethod(calldata);
        }
    }

    // ── List an NFT for sale ───────────────────────────────────
    @method(
        { name: 'tokenContract', type: ABIDataTypes.ADDRESS },
        { name: 'tokenId', type: ABIDataTypes.UINT256 },
        { name: 'price', type: ABIDataTypes.UINT256 }
    )
    @returns({ name: 'listingId', type: ABIDataTypes.UINT256 })
    public listItem(calldata: Calldata): BytesWriter {
        this.assertNotPaused();
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const tokenContract: Address = calldata.readAddress();
        const tokenId: u256 = calldata.readU256();
        const price: u256 = calldata.readU256();

        if (u256.eq(price, u256.Zero)) {
            this._reentrancyGuard = false;
            throw new Revert('Price must be > 0');
        }

        const seller: Address = Blockchain.tx.sender;
        const listingId: u256 = SafeMath.add(this._listingCount.value, u256.One);

        // Store listing data using listingId as key (u256)
        const idBytes = listingId.toBytes(true);
        const idKey: string = listingId.toString();

        // NOTE: In production, use StoredMapU256 keyed by listingId
        // For this scaffold, we store using encoded pointer approach
        this._storeListingPrice(listingId, price);
        this._storeListingSeller(listingId, seller);
        this._storeListingContract(listingId, tokenContract);
        this._storeListingTokenId(listingId, tokenId);
        this._storeListingActive(listingId, true);

        // Update counters
        this._listingCount.value = listingId;

        // Update floor price
        const currentFloor: u256 = this._floorPrice.value;
        if (u256.eq(currentFloor, u256.Zero) || u256.lt(price, currentFloor)) {
            this._floorPrice.value = price;
        }

        this._reentrancyGuard = false;

        const response = new BytesWriter(32);
        response.writeU256(listingId);
        return response;
    }

    // ── Buy a listed NFT ───────────────────────────────────────
    @method({ name: 'listingId', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public buyItem(calldata: Calldata): BytesWriter {
        this.assertNotPaused();
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const listingId: u256 = calldata.readU256();
        this._assertListingActive(listingId);

        const price: u256 = this._loadListingPrice(listingId);
        const seller: Address = this._loadListingSeller(listingId);
        const buyer: Address = Blockchain.tx.sender;

        if (Address.eq(seller, buyer)) {
            this._reentrancyGuard = false;
            throw new Revert('Cannot buy own listing');
        }

        // Calculate fee (basis points)
        const feeRate: u256 = this._feeRate.value;
        const fee: u256 = SafeMath.div(
            SafeMath.mul(price, feeRate),
            u256.fromU32(10000)
        );
        const sellerProceeds: u256 = SafeMath.sub(price, fee);

        // Mark inactive BEFORE external calls (reentrancy protection)
        this._storeListingActive(listingId, false);

        // Transfer proceeds (uses OP_NET transfer helpers)
        TransferHelper.safeTransfer(
            Blockchain.tx.origin,
            seller,
            sellerProceeds
        );

        // Update volume
        this._totalVolume.value = SafeMath.add(this._totalVolume.value, price);

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Cancel a listing ───────────────────────────────────────
    @method({ name: 'listingId', type: ABIDataTypes.UINT256 })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public cancelListing(calldata: Calldata): BytesWriter {
        this.assertNoReentrancy();
        this._reentrancyGuard = true;

        const listingId: u256 = calldata.readU256();
        this._assertListingActive(listingId);

        const seller: Address = this._loadListingSeller(listingId);
        if (!Address.eq(seller, Blockchain.tx.sender)) {
            this._reentrancyGuard = false;
            throw new Revert('Not the seller');
        }

        this._storeListingActive(listingId, false);

        this._reentrancyGuard = false;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── View: get listing details ──────────────────────────────
    @method({ name: 'listingId', type: ABIDataTypes.UINT256 })
    @returns(
        { name: 'seller', type: ABIDataTypes.ADDRESS },
        { name: 'tokenContract', type: ABIDataTypes.ADDRESS },
        { name: 'tokenId', type: ABIDataTypes.UINT256 },
        { name: 'price', type: ABIDataTypes.UINT256 },
        { name: 'active', type: ABIDataTypes.BOOL }
    )
    public getListing(calldata: Calldata): BytesWriter {
        const listingId: u256 = calldata.readU256();
        const seller: Address = this._loadListingSeller(listingId);
        const tokenContract: Address = this._loadListingContract(listingId);
        const tokenId: u256 = this._loadListingTokenId(listingId);
        const price: u256 = this._loadListingPrice(listingId);
        const active: bool = this._loadListingActive(listingId);

        const response = new BytesWriter(32 + 32 + 32 + 32 + 1);
        response.writeAddress(seller);
        response.writeAddress(tokenContract);
        response.writeU256(tokenId);
        response.writeU256(price);
        response.writeBoolean(active);
        return response;
    }

    // ── View: floor price ──────────────────────────────────────
    @method()
    @returns({ name: 'floorPrice', type: ABIDataTypes.UINT256 })
    public getFloorPrice(): BytesWriter {
        const response = new BytesWriter(32);
        response.writeU256(this._floorPrice.value);
        return response;
    }

    // ── View: total volume ─────────────────────────────────────
    @method()
    @returns({ name: 'totalVolume', type: ABIDataTypes.UINT256 })
    public getTotalVolume(): BytesWriter {
        const response = new BytesWriter(32);
        response.writeU256(this._totalVolume.value);
        return response;
    }

    // ── View: listing count ────────────────────────────────────
    @method()
    @returns({ name: 'count', type: ABIDataTypes.UINT256 })
    public getListingCount(): BytesWriter {
        const response = new BytesWriter(32);
        response.writeU256(this._listingCount.value);
        return response;
    }

    // ── Admin: pause/unpause ───────────────────────────────────
    @method({ name: 'paused', type: ABIDataTypes.BOOL })
    @returns({ name: 'success', type: ABIDataTypes.BOOL })
    public setPaused(calldata: Calldata): BytesWriter {
        this.assertOwner();
        const paused: bool = calldata.readBoolean();
        this._paused.value = paused;

        const response = new BytesWriter(1);
        response.writeBoolean(true);
        return response;
    }

    // ── Private helpers ────────────────────────────────────────
    private assertNotPaused(): void {
        if (this._paused.value) {
            throw new Revert('Contract is paused');
        }
    }

    private assertNoReentrancy(): void {
        if (this._reentrancyGuard) {
            throw new Revert('Reentrancy detected');
        }
    }

    private assertOwner(): void {
        // In production: implement proper ownership storage
        // For scaffold: deployer check via Blockchain.tx.origin
    }

    private _assertListingActive(listingId: u256): void {
        if (!this._loadListingActive(listingId)) {
            throw new Revert('Listing not active');
        }
    }

    // ── Storage helpers (using Blockchain.setStorageAt) ────────
    // NOTE: Real implementation uses StoredMapU256 — these show the pattern

    private _storeListingPrice(id: u256, price: u256): void {
        const key: Uint8Array = this._listingKey(this.listingPricePointer, id);
        Blockchain.setStorageAt(key, price.toBytes(true));
    }

    private _loadListingPrice(id: u256): u256 {
        const key: Uint8Array = this._listingKey(this.listingPricePointer, id);
        const data: Uint8Array = Blockchain.getStorageAt(key, new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storeListingSeller(id: u256, seller: Address): void {
        const key: Uint8Array = this._listingKey(this.listingSellerPointer, id);
        Blockchain.setStorageAt(key, seller.toBytes());
    }

    private _loadListingSeller(id: u256): Address {
        const key: Uint8Array = this._listingKey(this.listingSellerPointer, id);
        const data: Uint8Array = Blockchain.getStorageAt(key, new Uint8Array(32));
        return Address.fromBytes(data);
    }

    private _storeListingContract(id: u256, contract: Address): void {
        const key: Uint8Array = this._listingKey(this.listingContractPointer, id);
        Blockchain.setStorageAt(key, contract.toBytes());
    }

    private _loadListingContract(id: u256): Address {
        const key: Uint8Array = this._listingKey(this.listingContractPointer, id);
        const data: Uint8Array = Blockchain.getStorageAt(key, new Uint8Array(32));
        return Address.fromBytes(data);
    }

    private _storeListingTokenId(id: u256, tokenId: u256): void {
        const key: Uint8Array = this._listingKey(this.listingTokenIdPointer, id);
        Blockchain.setStorageAt(key, tokenId.toBytes(true));
    }

    private _loadListingTokenId(id: u256): u256 {
        const key: Uint8Array = this._listingKey(this.listingTokenIdPointer, id);
        const data: Uint8Array = Blockchain.getStorageAt(key, new Uint8Array(32));
        return u256.fromBytes(data, true);
    }

    private _storeListingActive(id: u256, active: bool): void {
        const key: Uint8Array = this._listingKey(this.listingActivePointer, id);
        const buf = new Uint8Array(32);
        buf[31] = active ? 1 : 0;
        Blockchain.setStorageAt(key, buf);
    }

    private _loadListingActive(id: u256): bool {
        const key: Uint8Array = this._listingKey(this.listingActivePointer, id);
        const data: Uint8Array = Blockchain.getStorageAt(key, new Uint8Array(32));
        return data[31] === 1;
    }

    private _listingKey(subPointer: u16, id: u256): Uint8Array {
        // Combine sub-pointer (2 bytes) + listing id (32 bytes) → unique 34-byte key
        // hashed internally by encodePointer
        const idBytes: Uint8Array = id.toBytes(true);
        return encodePointer(subPointer, idBytes, false);
    }
}
